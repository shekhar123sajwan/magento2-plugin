<?php

namespace Ehub\VillageVoice\Controller;

class Router implements \Magento\Framework\App\RouterInterface {

    protected $_actionFactory;
    protected $_storeManager;
    protected $_scopeConfig;
    protected $_attributeCode;
    protected $_category;

    /**
     * @var \Magento\Framework\Registry
     */
    protected $_registry;

    public function __construct(
    \Magento\Framework\App\ActionFactory $actionFactory, 
            \Magento\Store\Model\StoreManagerInterface $storeManager, 
            \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, 
            \Magento\Framework\Registry $registry,
            \Ehub\VillageVoice\Model\Category $category
    ) {
        $this->_actionFactory = $actionFactory;
        $this->_storeManager = $storeManager;
        $this->_scopeConfig = $scopeConfig;
        $this->_registry = $registry;
        $this->_category = $category;
    }

    /**
     * Validate village Voice Category Page and render category page
     *
     * @param \Magento\Framework\App\RequestInterface $request
     * @return bool
     */
    public function match(\Magento\Framework\App\RequestInterface $request) {
        $pathInfo = trim($request->getPathInfo(), '/');
        $urlKey = explode('/', $pathInfo);
        var_dump($urlKey);
        if (isset($urlKey[1]) && ($urlKey[0] == 'voice') && $urlKey[1] == 'category') {
            $urlKey = strtolower(urldecode($urlKey[2]));

            $collection = $this->_category->getCollection()->addFieldToFilter('c_url_key', $urlKey);

            $category = $collection->getFirstItem();

            if ($category->getCId()) {
                $request->setModuleName('voice')
                        ->setControllerName('category')
                        ->setActionName('Index')
                        ->setParam('c_id', $category->getCId());

                $this->_registry->register('vv_current_category', $category);
                $request->setAlias(\Magento\Framework\Url::REWRITE_REQUEST_PATH_ALIAS, 'voice/' . $urlKey);

                return $this->_actionFactory->create('Magento\Framework\App\Action\Forward');
            }
        }

        return null;
    }

}
