<?php

namespace Ehub\VillageVoice\Model;

class Videos extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface {

    const CACHE_TAG = 'voice_videos';

    protected $_cacheTag = 'voice_videos';
    protected $_eventPrefix = 'voice_videos';

    protected function _construct()
    {
        $this->_init('Ehub\VillageVoice\Model\ResourceModel\Videos');
    }
    
    public function getIdentities() {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getDefaultValues() {
        $values = [];

        return $values;
    }

}
