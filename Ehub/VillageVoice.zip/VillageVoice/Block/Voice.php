<?php

namespace Ehub\VillageVoice\Block;

class Voice extends \Magento\Framework\View\Element\Template {

    protected $_categoryFactory;
    
    public function __construct(
    \Magento\Framework\View\Element\Template\Context $context, \Ehub\VillageVoice\Helper\Data $helperData,
 \Ehub\VillageVoice\Model\Category $category, \Ehub\VillageVoice\Helper\Category $categoryHelper
    ) {
        parent::__construct($context);
        $this->helperData = $helperData;
        $this->_categoryFactory = $category;
        $this->_categoryHelper = $categoryHelper;
    }

    protected function _prepareLayout()
    {
        parent::_prepareLayout();
        //if(!$this->getStatus()){
        //    $this->setTemplate('Ehub_VillageVoice::module_disabled.phtml');
        //}
        return $this;
    }

    public function getStatus() {
        return $this->helperData->getGeneralConfig('enable');
    }

    public function getAllCategories(){
        $collection = $this->_categoryFactory->getCollection();
        $collection->addFieldToFilter('c_status', 1);
        return $collection;
    }
    
    public function getCategoryImage($banner){
        return $this->_categoryHelper->getCategoryBanner($banner);
    }
}
