<?php

namespace Ehub\VillageVoice\Block\Adminhtml\Users;

use Magento\Backend\Block\Widget\Grid as WidgetGrid;

class Grid extends WidgetGrid
{
   
}
